export class Clientes {
    id:number;
    nombre:string;
    correo:string;
    telefono:string;
    fecha:string;
    ciudad:string;
}
